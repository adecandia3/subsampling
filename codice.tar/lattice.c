#ifndef __LATTICE_H__
#define __LATTICE_H__

class lattice
  {
   public:
   lattice(int L);

   int M;
   int *z;
   int **who;
   char **name;
  };

#ifndef __HEADERS__
#include <stdio.h>
#include <math.h>
#define __HEADERS__
#include "getarg.c"
#include "getmem.c"
#include "debug.c"

lattice::lattice(int L)
  {
   int type=1;
   int nmax=L*L;					// number of sites
   int zmax=getarg_i("zmax",64,"maximum number of sublattices");
   int nmin=getarg_i("nmin",64,"minimum size of sublattices");
   int ptmp=getarg_i("pmin",4,"size ratio between sublattices");
   int pmin=0;
   while (ptmp>1)
     {
      if (ptmp%2) debug(9,"pmin has to be a power of 2\n");
      ptmp/=2;
      pmin++;
     }
   int bmax=(int)rint(sqrt(zmax));
   int lmin=(int)rint(sqrt(nmin));
   int lmax=(int)rint(sqrt(nmax));
   if (zmax!=bmax*bmax || nmin!=lmin*lmin || nmax!=lmax*lmax || pmin%2!=0) debug(9,"zmax, nmin e nmax devono essere quadrati...pmin deve essere pari\n");
   int l=(L<lmax?L:lmax);
   int N=L*L;
   M=0;
   while (l>=lmin)
     {
      int a=L/l;                                                                // il reticolo L*L è diviso in a*a sottoreticoli l*l
      int b=(a<bmax?a:bmax);                                	                    // prendi b*b sottoreticoli (a è multiplo di b)
      if (L%l!=0 || a%b!=0) debug(9,"L, lmax, bmax devono essere potenze di 2\n");
      int kmax=b*b;                                                                     // numero sottoreticoli
      who=(int**)getmem(who,(M+1)*sizeof(int*));
      z=(int*)getmem(z,(M+1)*sizeof(int));
      z[M]=kmax;
      who[M]=ivector(0,N-1);
      // trova i siti appartenenti al sottoreticolo k-mo della size M
      int q=a/b;
      for (int i=0;i<N;i++)
        {
         int ix=i%L;
         int iy=i/L;
         int jx,jy;
         if (type==0)
           {
            jx=ix/l;            // jx e jy vanno da 0 ad a-1...
            jy=iy/l;
           }
         else
           {
            jx=ix%a;
            jy=iy%a;
           }
         if (jx%q==0 && jy%q==0)        // jx/q e jy/q vanno da 0 a b-1
           {
            int k=(jx/q)+b*(jy/q);
            who[M][i]=k;        // il sito i-mo appartiene al sottoreticolo k-mo
           }
         else who[M][i]=kmax;
        }
      name=(char**)getmem(name,(M+1)*sizeof(char*));
      name[M]=(char*)getmem(NULL,32*sizeof(char));
      sprintf(name[M],"%g",2*log(l)/M_LN2);
      //double mem=48+N*4+kmax*8;
      //debug(0,"l=%-5i kmax=%-8i mem=%g Gb\n",l,kmax,1e-9*mem);
      M++;
      l/=(1<<(pmin/2));
     }
  }
#endif
#endif
