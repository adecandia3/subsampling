#include <stdio.h>
#include <math.h>
#define __HEADERS__
#include "pvm.c"
#include "getarg.c"
#include "getmem.c"
#include "debug.c"
#include "cpu.c"
#include "branch.c"
#include "shape.c"
#include "power.c"
#include "dfa.c"
#include "memory.c"
#include "power2.c"

int main(int argc,char **argv)
  {
   getarg_i("cpu",3600,"total time of the simulation");
   //getarg_i("save",5);
   pvm_init();
   int mype=pvm_mype();

   int topo=getarg_i("topo",0,"topology of the lattice (0==fully connected, 1==two dimensional)");
   int N=getarg_i("N",1<<24,"total number of sites");

   double mu=0.1;
   branch *Q= new branch();

   shape **Y=(shape**)getmem(NULL,Q->M*sizeof(shape*));
   power2 **Z=(power2**)getmem(NULL,Q->M*sizeof(power2*));
   dfa2 **K=(dfa2**)getmem(NULL,Q->M*sizeof(dfa2*));
   for (int m=0;m<Q->M;m++)
     {
      char name2[128];
      sprintf(name2,"%i-%g-%s",topo,log(N)/M_LN2,Q->name[m]);
      //debug(0,"shape... %i\n",m);
      Y[m]=new shape(Q->z[m],name2);
      //debug(0,"power2... %i\n",m);
      Z[m]=new power2(Q->z[m],name2);
      //debug(0,"dfa2... %i\n",m);
      K[m]=new dfa2(Q->z[m],name2);
     }

   char name[128];
   sprintf(name,"%i-%g",topo,log(N)/M_LN2);
   //double mem=memory();
   //debug(0,"\ntotal memory allocated: %g Gb\n",1e-9*mem);
   debug(0,"start of avalanche production...\n");
   long count=0;						// count steps
   while (1)
     {
      Q->step();
      for (int m=0;m<Q->M;m++)
        {
         Y[m]->push(Q->nhit[m]);
         Z[m]->push(Q->nhit[m]);
         K[m]->push(Q->nhit[m]);
        }
      count++;
      if (cpuint() || cputerm())
        {
         for (int m=0;m<Q->M;m++)
           {
            Y[m]->save();
            Z[m]->save();
            K[m]->save();
           }
         //mem=memory();
         //debug(0,"total memory allocated: %g Gb\n",1e-9*mem);
         debug(0,"number of steps: %li\n",count);
         if (cputerm()) break;
        }
     }

   pvm_end();
   return 0;
  }
