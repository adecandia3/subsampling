#ifndef __PVM_H__
#define __PVM_H__
#include <stdlib.h>

void pvm_init(int *argc=NULL,char ***argv=NULL);
void pvm_end(void);
int pvm_mype(void);
int pvm_debug(void);

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#define __HEADERS__
#include "debug.c"
#include "mpi.c"
#include "random.c"
#include "cpu.c"
#include "getmem.c"
#include "fopenf.c"
#include "getarg.c"

static int mype;
static int npes;
static int mype2;	
static int npes2;	
static int nfile;
static int flag;	

void pvm_init(int *argc,char ***argv)
  {
   mpi_init(argc,argv);
   init_args(argc,argv);

   flag=getarg_i("#debug",1);
   if (flag==0) args_out("getarg.log");

   mype=getarg_i("#mype",0);
   npes=getarg_i("#npes",1);
   mype2=mpi_mype();
   npes2=mpi_npes();

   int off=mype*npes2+mype2;
   char buffer[PATH_MAX];
   if (flag==0 || npes>1 || npes2>1)
     {
      sprintf(buffer,"RUN/%03i/",off);
      makedir(buffer);
      if (chdir(buffer)) debug(9,"pvm: errore in chdir(\"%s\")...\n",buffer);
     }

   char *path=getarg_s("#output");
   if (flag==0 && path==NULL)
     {
      path=(char*)realloc(path,24*sizeof(char));
      strcpy(path,"mpirun.log");
     }
   if (path)
     {
      makedir(path);
      if (freopen(path,"a",stdout)==NULL) debug(9,"pvm: errore in freopenf(%s)\n",path);
      if (dup2(STDOUT_FILENO,STDERR_FILENO)==-1) debug(9,"pvm: errore in dup2\n");
     }
   setlinebuf(stdout);

   double cpu=getarg_d("#cpu",0.);
   double save=getarg_d("#save",0.);
   cpustart(cpu,save);

   int seed=getarg_i("seed",(int)time(NULL),"seed random number generator");
   int seed2=getarg_i("#seed2",off);
   init_random(seed,seed2);
  }

int pvm_mype(void) {return mype;}
int pvm_debug(void) {return flag;}				
void pvm_end(void) {mpi_end();}

#endif
#endif
