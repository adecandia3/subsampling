#ifndef __DFA2_H__
#define __DFA2_H__

class dfa2
  {
   public:
   dfa2(int M,char *name);
   void resize(void);
   void push(double *frate);
   void save(void);

   int M;
   char *name;

   double ppdec;
   int hmax;
   long *n;
   double **Y;
   double **Ys;
   double **Yt;
   double **Y2;
   double *F;
   double *norm;
   long count;
   char *tmpdir;
  };

#ifndef __HEADERS__
#include <stdio.h>
#include <math.h>
#include <string.h>
#define __HEADERS__
#include "debug.c"
#include "getarg.c"
#include "getmem.c"
#include "fopenf.c"

dfa2::dfa2(int _M,char *_name)
  {
   //debug(0,"dfa2: M=%i name=%s\n",_M,_name);
   M=_M;
   int l=strlen(_name);
   name=(char*)getmem(NULL,(l+1)*sizeof(char));
   strcpy(name,_name);

   long nmin=4;
   ppdec=10;
   hmax=0;
   Y=dmatrix(0,0,0,M-1);
   Ys=dmatrix(0,0,0,M-1);
   Yt=dmatrix(0,0,0,M-1);
   Y2=dmatrix(0,0,0,M-1);
   F=dvector(0,0);
   norm=dvector(0,0);
   n=(long*)getmem(NULL,sizeof(long));
   n[0]=nmin;
   count=0;
   //debug(0,"end...\n");
   tmpdir=getarg_s("tmpdir",".","output directory");
  }

void dfa2::resize(void)
  {
   double nnew=ceil(n[hmax]*pow(10,1/ppdec));
   if (nnew>1e18) return;
   hmax++;
   Y=(double**)getmem(Y,(hmax+1)*sizeof(double*));
   Y[0]=(double*)getmem(Y[0],M*(hmax+1)*sizeof(double));
   Ys=(double**)getmem(Ys,(hmax+1)*sizeof(double*));
   Ys[0]=(double*)getmem(Ys[0],M*(hmax+1)*sizeof(double));
   Yt=(double**)getmem(Yt,(hmax+1)*sizeof(double*));
   Yt[0]=(double*)getmem(Yt[0],M*(hmax+1)*sizeof(double));
   Y2=(double**)getmem(Y2,(hmax+1)*sizeof(double*));
   Y2[0]=(double*)getmem(Y2[0],M*(hmax+1)*sizeof(double));
   for (int h=1;h<=hmax;h++)
     {
      Y[h]=Y[h-1]+M;
      Ys[h]=Ys[h-1]+M;
      Yt[h]=Yt[h-1]+M;
      Y2[h]=Y2[h-1]+M;
     }
   for (int m=0;m<M-1;m++)
     {
      Y[hmax][m]=Y[hmax-1][m];
      Ys[hmax][m]=Y[hmax-1][m];
      Yt[hmax][m]=Y[hmax-1][m];
      Y2[hmax][m]=Y[hmax-1][m];
     }
   F=(double*)getmem(F,(hmax+1)*sizeof(double));
   norm=(double*)getmem(norm,(hmax+1)*sizeof(double));
   n=(long*)getmem(n,(hmax+1)*sizeof(long));
   F[hmax]=0;
   norm[hmax]=0;
   n[hmax]=(long)nnew;
  }

void dfa2::push(double *frate)
  {
   //debug(0,"=========== count=%li ============\n",count);
   int h=0;
   while (h<=hmax)
     {
      long t=count%n[h];                   // tempo all'interno dell'intervallo
      // accumula per il tempo t
      for (int m=0;m<M;m++)
        {
         Y[h][m]+=frate[m];             // funzione cumulativa della serie m-ma relativa all'intervallo di lunghezza h
         Ys[h][m]+=Y[h][m];
         Yt[h][m]+=t*Y[h][m];
         Y2[h][m]+=Y[h][m]*Y[h][m];
        }
      if (t==n[h]-1)
        {
         double st=n[h]*(n[h]-1.)/2;                       // 0 + 1 + 2 + ... + (n-1)
         double st2=n[h]*(n[h]-1.)*(2*n[h]-1.)/6;        // 0 + 1 + 4 + ... + (n-1)^2
         double del=n[h]*st2-st*st;
         for (int m=0;m<M;m++)
           {
            // trova fit lineare nell'intervallo
            double a=(st2*Ys[h][m]-st*Yt[h][m])/del;
            double b=(n[h]*Yt[h][m]-st*Ys[h][m])/del;
            F[h]+=Y2[h][m]-2*a*Ys[h][m]-2*b*Yt[h][m]+n[h]*a*a+2*a*b*st+b*b*st2;
           }
         norm[h]+=M*(double)n[h];
         // se h==hmax aumenta hmax
         if (h==hmax) resize();
         // azzera accumulatori
         for (int m=0;m<M;m++) Y[h][m]=Ys[h][m]=Yt[h][m]=Y2[h][m]=0;
        }
      h++;
     }
   count++;
  }

void dfa2::save(void)
  {
   FILE *stream=fopenf("%s/dfa-%s.dat","w",tmpdir,name);
   double nold=0;
   double fold=0;
   for (int h=0;h<=hmax;h++) if (norm[h]>0)
     {
      double ftmp=sqrt(F[h]/norm[h]);
      double d=log(ftmp/fold)/log(n[h]/nold);
      fprintf(stream,"%12li %12g %12g\n",n[h],ftmp,d);
      nold=n[h];
      fold=ftmp;
     }
   fclose(stream);
  }
#endif
#endif
