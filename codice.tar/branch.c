#ifndef __BRANCH_H__
#define __BRANCH_H__

class branch
  {
   public:
   branch(void);
   void step(void);

   int topo;
   double mu;
   double pbond;
   int d;
   int h;
   int L;
   int N;
   int *n;			// siti del sottoreticolo
   int **next;
   int *stack;
   int *stack2;
   int *heap;
   int *S;
   int **who;
   int ntot;
   double **nhit;
   int M;
   int *z;
   char **name;
   int bin;
  };

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define __HEADERS__
#include "getarg.c"
#include "getmem.c"
#include "neighbors.c"
#include "random.c"
#include "lattice.c"
#include "permuta.c"
#include "bnldev.c"
#include "debug.c"

branch::branch(void)
  {
   topo=getarg_i("topo",0);
   mu=getarg_d("#mu",0.01);
   if (topo==0)
     {
      double sigma=getarg_d("sigma",1,"branching ratio");                           // branching ratio
      N=getarg_i("N",1<<20);
      pbond=sigma/N;
      // definisci sottoreticoli
      int nmax=getarg_i("#nmax",N);
      int nmin=getarg_i("nmin",64,"minimum dimension of sublattices");
      int zmax=getarg_i("zmax",64,"maximum number of sublattices");
      int ptmp=getarg_i("pmin",4,"size ratio between sublattices");
      int pmin=0;
      while (ptmp>1)
        {
         if (ptmp%2) debug(9,"pmin has to be a power of 2\n");
         ptmp/=2;
         pmin++;
        }
      //debug(0,"log_2(pmin)=%i\n",pmin);
      M=0;
      n=z=NULL;
      who=NULL;
      name=NULL;
      int ntmp=nmax;
      while (ntmp>=nmin)
        {
         n=(int*)getmem(n,(M+1)*sizeof(int));
         z=(int*)getmem(z,(M+1)*sizeof(int));
         who=(int**)getmem(who,(M+1)*sizeof(int*));
         n[M]=ntmp;
         int ztmp=N/ntmp;                                  // sottoreticoli totali (attivi e non attivi)
         z[M]=(ztmp<zmax?ztmp:zmax);                       // quanti attivi
         if (N<=0 || ntmp<=0 || N%ntmp!=0 || z[M]<=0 || ztmp%z[M]!=0) debug(9,"N, nmax e zmax devono essere potenze di 2...\n");
         //printf("sottoreticoli: %i, siti nel sottoreticolo: %i (totale %i)\n",z[M],ntmp,z[M]*ntmp);
         who[M]=ivector(0,N-1);
         for (int i=0;i<N;i++)
           {
            // trova a quale dei z[M] sottoreticoli di dimensione ntmp appartiene il sito i-mo (who[M][i]>=z[M] se non appartiene a nessuno)
            who[M][i]=i/ntmp;
           }
         name=(char**)getmem(name,(M+1)*sizeof(char*));
         name[M]=(char*)getmem(NULL,64*sizeof(char));
         //sprintf(name[M],"%g-%g",log(N)/M_LN2,log(ntmp)/M_LN2);
         sprintf(name[M],"%g",log(ntmp)/M_LN2);
         M++;
         ntmp/=(1<<pmin);
        }
      bin=getarg_i("bin",1,"temporal step");
     }
   else
     {
      // directed percolation
      double pc=0.28730;				// probabilità critica, vedi Grassberger, J. Phys. A 22, 3673 (1989) per reticolo BCC, bond
      pbond=getarg_d("pbond",pc,"bond probability for directed percolation");
      N=getarg_i("N",1024);
      d=2;
      h=4;
      L=(int)rint(sqrt(N));
      if (N!=L*L) debug(9,"directed percolation: N should be a perfect square...\n");
      next=neighbors(d,L);
      lattice *Y=new lattice(L);
      M=Y->M;
      z=Y->z;
      name=Y->name;
      who=Y->who;
      bin=getarg_i("bin",2,"temporal step (at least 2 for directed percolation)");		// N.B: serve almeno bin=2 per sottoreticoli a scacchiera
     }
   S=ivector(0,N-1);
   stack=ivector(0,N-1);
   stack2=ivector(0,N-1);
   heap=ivector(0,N-1);
   for (int i=0;i<N;i++) heap[i]=i;
   nhit=(double**)getmem(NULL,M*sizeof(double*));
   for (int m=0;m<M;m++) nhit[m]=dvector(0,z[m]-1);
   ntot=0;
  }

void branch::step(void)
  {
   for (int m=0;m<M;m++) for (int k=0;k<z[m];k++) nhit[m][k]=0;
   for (int u=0;u<bin;u++)
     {
      if (ntot>0)
        {
         int ntmp=ntot;
         ntot=0;
         for (int i=0;i<ntmp;i++)
           {
            // trova quali siti vengono attivati dall'i-mo sito attivo... i siti attivi sono contenuti in stack[]
            int k=0;
            if (topo==0)
              {
               k=bnldev(pbond,N);
               permuta(k,N,heap);		// se topo==0 heap contiene sempre tutti gli N siti in ordine casuale
              }
            else
              {
               int j=stack[i];
               for (int l=0;l<h;l++) if (Xrandom()<pbond) heap[k++]=next[l][j];
              }
            for (int l=0;l<k;l++)
              {
               int j=heap[l];
               if (S[j]==0)
                 {
                  S[j]=1;
                  stack2[ntot]=j;
                  ntot++;
                 }
              }
           }
        }
      else if (Xrandom()<mu)    // inizia valanga sempre all'inizio del bin
        {
         int j=(int)floor(N*Xrandom());
         stack2[0]=j;
         ntot=1;
        }
      for (int i=0;i<ntot;i++)
        {
         int j=stack2[i];
         for (int m=0;m<M;m++)
           {
            int k=who[m][j];
            if (k<z[m]) nhit[m][k]++;
           }
         S[j]=0;
         stack[i]=j;
        }
     }
  }
#endif
#endif
