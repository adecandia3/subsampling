#ifndef __POWER2_H__
#define __POWER2_H__

class power2
  {
   public:
   power2(int M,char *name);
   void push(double *frate);
   void save(void);

   int M;
   char *name;
   int nmax;
   int np;
   int wmax;

   double *P;
   double *norm;
   double **x;
   double **p;

   int n;
   double count;
   char *tmpdir;
  };

#ifndef __HEADERS__
#include <stdio.h>
#include <math.h>
#include <string.h>
#define __HEADERS__
#include "debug.c"
#include "getarg.c"
#include "getmem.c"
#include "fopenf.c"
#include "power.c"

power2::power2(int _M,char *_name)
  {
   M=_M;
   int l=strlen(_name);
   name=(char*)getmem(NULL,(l+1)*sizeof(char));
   strcpy(name,_name);

   nmax=getarg_i("nwin",1<<18,"window for calculation of the spectrum");                      // finestra per il calcolo dello spettro (potenza di 2)
   np=nmax/2;

   double ppdec=20;
   wmax=(int)ceil(ppdec*log(np)/M_LN10);                                // bin logaritmici spettro
   P=dvector(0,wmax-1);                                                          // spettro in scala logaritmica
   norm=dvector(0,wmax-1);                                                       // quante frequenze ci sono nel bin logaritmico
   for (int u=1;u<=np;u++)
     {
      int w=(int)floor(wmax*log(u)/log(np));
      if (w>=0 && w<wmax) norm[w]++;
     }

   //debug(0,"power2: M=%i... nmax=%i: %li\n",M,nmax,8*M*(long)nmax);
   x=dmatrix(0,M-1,0,nmax-1);
   //debug(0,"power2: M=%i... np=%i: %li\n",M,nmax,8*M*(long)np);
   p=dmatrix(0,M-1,0,np);
   n=0;
   count=0;
   tmpdir=getarg_s("tmpdir",".","output directory");
  }

void power2::push(double *frate)
  {
   for (int m=0;m<M;m++) x[m][n]=frate[m];
   n++;
   if (n==nmax)
     {
      for (int m=0;m<M;m++)
        {
         double xm=0;
         for (int i=0;i<nmax;i++) xm+=x[m][i];
         for (int i=0;i<nmax;i++) x[m][i]-=xm/nmax;
         power(x[m],nmax,p[m]);
        }
      count++;
      n=0;
     }
  }

void power2::save(void)
  {
   for (int w=0;w<wmax;w++) P[w]=0;
   for (int u=1;u<=np;u++)
     {
      int w=(int)floor(wmax*log(u)/log(np));
      if (w>=0 && w<wmax) for (int m=0;m<M;m++) P[w]+=p[m][u];
     }
   FILE *stream=fopenf("%s/power-%s.dat","w",tmpdir,name);
   double uold=0;
   double pold=0;
   for (int w=0;w<wmax;w++) if (norm[w]>0)
     {
      double u1=exp(w*log(np)/wmax);
      double u2=exp((w+1)*log(np)/wmax);
      double um=sqrt(u1*u2)/nmax;
      double ptmp=P[w]/(norm[w]*count*M);
      fprintf(stream,"%12g %12g %12g\n",um,ptmp,log(ptmp/pold)/log(um/uold));
      uold=um;
      pold=ptmp;
     }
   fclose(stream);
  }
#endif
#endif
