#ifndef __DEBUG_H__
#define __DEBUG_H__

void block_debug(int level);
void debug(int level,const char *format,...);

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <math.h>

static int block;
void block_debug(int level) {block=level;}

void debug(int level,const char *format,...)
  {
   if (level&8 || (level&block)==0)
     {
      va_list ap;
      va_start(ap,format);
      vfprintf(stderr,format,ap);
      va_end(ap);
      if (level&8)
        {
         exit(1);
        }
     }
  }
#endif
#endif
