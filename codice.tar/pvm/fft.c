#ifndef __FFT_H__
#define __FFT_H__

void fft(double *x,int nn);

#ifndef __HEADERS__
#include <math.h>
 
void fft(double *x,int nn)
  {
   int n,i,j,m,istep,mmax;
   double xtmp,theta,wtmp,wr,wi,wpr,wpi,tmpr,tmpi;

   n=nn<<1;
   j=0;				
   for (i=0;i<n-1;i+=2)
     {
      if (j>i)
        {
         xtmp=x[j];
         x[j]=x[i];
         x[i]=xtmp;
         xtmp=x[j+1];
         x[j+1]=x[i+1];
         x[i+1]=xtmp;
        }
      m=n>>1;
      while (m>=2 && j>=m)
        {
         j-=m;
         m>>=1;
        }
      j+=m;
     }
   mmax=2;                   
   while (n>mmax)
     {
      istep=mmax<<1;
      theta=2*M_PI/mmax;
      wtmp=sin(0.5*theta);
      wpr=-2.0*wtmp*wtmp;
      wpi=sin(theta);
      wr=1.0;
      wi=0.0;
      for (m=0;m<mmax-1;m+=2)
        {
         for (i=m;i<n;i+=istep)
           {
            j=i+mmax;
            tmpr=wr*x[j]-wi*x[j+1];
            tmpi=wr*x[j+1]+wi*x[j];
            x[j]=x[i]-tmpr;
            x[j+1]=x[i+1]-tmpi;
            x[i]+=tmpr;
            x[i+1]+=tmpi;
           }
         wr=(wtmp=wr)*wpr-wi*wpi+wr;
         wi=wi*wpr+wtmp*wpi+wi;
        }
      mmax=istep;
     }
  }
#endif
#endif
