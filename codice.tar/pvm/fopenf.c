#ifndef __FOPENF_H__
#define __FOPENF_H__
#include <stdio.h>

int makedir(const char *path,int mode=0755);
FILE *fopenf(const char *format,const char *mode,...);
void homestrip(const char *path,char *buffer);

#ifndef __HEADERS__
#include <limits.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#define __HEADERS__
#include "debug.c"

int makedir(const char *path,int mode)
  {
   char buffer[PATH_MAX];
   strcpy(buffer,path);
   char *p=buffer;
   char *q;
   while ((q=strchr(p,'/')))
     {
      *q='\0';
      int err=mkdir(buffer,mode);		
      *q='/';
      p=q+1;
     }
   return 0;
  }

FILE *fopenf(const char *format,const char *mode,...)
  {
   if (strcmp(mode,"r") && strcmp(mode,"w") && strcmp(mode,"a")) debug(9,"fopenf: mode \"%s\" non riconosciuto\n",mode);
   char path[PATH_MAX],buffer[PATH_MAX];
   va_list ap;
   va_start(ap,mode);
   vsprintf(path,format,ap);
   va_end(ap);
   homestrip(path,buffer);
   if (strcmp(mode,"r")) makedir(buffer);
   FILE *stream=fopen(buffer,mode);
   return stream;
  }

void homestrip(const char *path,char *buffer)
  {
   uid_t uid=getuid();
   struct passwd *pw=getpwuid(uid);
   if (strncmp(path,"$HOME/",6)==0 || strncmp(path,"$home/",6)==0)
     {
      sprintf(buffer,"%s/%s",pw->pw_dir,path+6);
     }
   else if (strncmp(path,"$TMPDIR/",8)==0 || strncmp(path,"$tmpdir/",8)==0)
     {
      char buff2[PATH_MAX];
      FILE *stream=fopen(".tmpdir","r");
      if (stream==NULL) debug(9,"fopenf: file .tmpdir non trovato...\n");
      fscanf(stream,"%s",buff2);
      fclose(stream);
      sprintf(buffer,"%s/.jobs/temp_%s/%s",pw->pw_dir,buff2,path+8);
     }
   else strcpy(buffer,path);
  }
#endif
#endif
