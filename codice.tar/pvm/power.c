#ifndef __POWER_H__
#define __POWER_H__

void power(double *x,int n,double *p);

#ifndef __HEADERS__
#include <stdlib.h>
#include <math.h>
#define __HEADERS__
#include "realft.c"

#define WINDOW(j,m)  (1.0-fabs(((j)-(m))/(double)(m)))  

void power(double *x,int n,double *p)
  {
   int m,i,i1,i2;
   double wtmp,sum;
 
   m=n>>1;
   sum=0.0;
   for (i=0;i<n;i++)
     {
      x[i]*=(wtmp=WINDOW(i,m));
      sum+=wtmp*wtmp;
     }
   realft(x,n);
   p[0]+=x[0]*x[0]/sum;
   for (i=1;i<m;i++)
     {
      i1=i<<1;
      i2=i1+1;
      p[i]+=(x[i1]*x[i1]+x[i2]*x[i2])/sum;
     }
   p[m]+=x[1]*x[1]/sum;
  }
#endif
#endif
