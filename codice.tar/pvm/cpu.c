#ifndef __CPU_H__
#define __CPU_H__
#include <stdlib.h>

void cpustart(double cpu=0.,double save=0.);
double cputime(double *stime=NULL);
double walltime(void);
int cpuint(int level=0);
int cputerm(int reset=0);
int cpunext(int skip=0);

#ifndef __HEADERS__
#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>



static double cpu;		
static double save;

static int init_cpu;
static double start;		
static int flag;		
static double ctrc;	
static double last;		

static double tmin=10;		
static double tmax=10000;	
static double tdelta;		
static double tnext;		

#define lmax 16
static int ftmp[lmax];

#define TBIG 1e30

static void handler(int signum)
  {
   if (signum==SIGTERM) flag=1;
   else if (signum==SIGINT)
     {
      double now=walltime();
      if (ctrc<TBIG && now<ctrc+1)
        {
         ctrc=TBIG;
         flag=1;	
        }
      else ctrc=now;		
     }
   signal(signum,handler);
  }

double cputime(double *_stime)
  {
   struct rusage usage;
   if (getrusage(RUSAGE_SELF,&usage))
     {
      fprintf(stderr,"cputime: errore in getrusage\n");
      exit(1);
     }
   double utime=(double)usage.ru_utime.tv_sec+1e-6*(double)usage.ru_utime.tv_usec;		
   double stime=(double)usage.ru_stime.tv_sec+1e-6*(double)usage.ru_stime.tv_usec;		
   if (_stime) *_stime=stime;
   return utime+stime;
  }

double walltime(void)
  {
   if (init_cpu==0) cpustart(0.,0.);
   struct timespec tp;
   clock_gettime(CLOCK_MONOTONIC_RAW,&tp);
   return (double)tp.tv_sec+1e-9*(double)tp.tv_nsec-start;
  }

void cpustart(double _cpu,double _save)
  {
   init_cpu++;			
   if (_cpu>0) cpu=_cpu;
   if (_save>0) save=_save;
   if (init_cpu==1) start=walltime();
   signal(SIGINT,handler);
   signal(SIGTERM,handler);
   ctrc=TBIG;
   tdelta=tnext=tmin;
  }

int cpunext(int skip)
  {
   double now=walltime();
   if (now>=tnext)
     {
      if (skip==0)	
        {
         if (tdelta<tmax) tdelta*=2;
         do {tnext+=tdelta;} while (tnext<=now);
        }
      return 1;
     }
   else return 0;
  }


int cpuint(int level)
  {
   if (level<0) level=0;
   if (level>=lmax) level=lmax-1;
   if (flag && level==0)    
     {
      static int count;
      count++;
      int cmax=100;
      if (count>=cmax)
        {
         fprintf(stderr,"... loop infinito cpuint? ...\n");
         exit(1);
        }
     }
   double now=walltime();
   int flag2=0;
   if (now>ctrc+1)
     {
      ctrc=TBIG;
      last=now;
      flag2=1;
     }
   else if (save>0 && now>last+save) 
     {
      last=now;
      flag2=1;
     }
   int fret=ftmp[level];
   if (flag2)
     {
      for (int l=0;l<level;l++) ftmp[l]=1;
      fret=1;
     }
   else ftmp[level]=0;
   return fret;
  }

int cputerm(int reset)
  {
   static double next;
   double now=walltime();
   if (cpu<=0 || now<cpu)
     {
      if (now>next)
        {
         struct stat buf;
         if (lstat("STOP",&buf)==0 && S_ISREG(buf.st_mode)) flag=1;
         next+=600;
        }
      if (reset) flag=0;
      return flag;
     }
   else return 1;
  }
#endif
#endif
