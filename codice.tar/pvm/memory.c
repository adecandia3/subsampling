#ifndef __MEMORY_H__
#define __MEMORY_H__

double memory(void);

#ifndef __HEADERS__
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define MAXBUF 4096

double memory(void)
  {
   int pid=getpid();
   char buffer[MAXBUF];
   sprintf(buffer,"/proc/%i/stat",pid);
   int fd=open(buffer,O_RDONLY,0);
   if (fd<0)
     {
     }
   int c=read(fd,buffer,MAXBUF-1);
   buffer[c]='\0';
   close(fd);
   char *p2=strchr(buffer,')');
   unsigned long vsize;
   sscanf(p2+2,"%*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %*d %*d %*d %*d %*d %*d %*d %*d %*u %lu",&vsize);
   return (double)vsize;
  }
#endif
#endif
