#ifndef __SHAPE_H__
#define __SHAPE_H__

class shape
  {
   public:
   shape(int M,char *name);
   void push(double *frate);		// questa funzione va chiamata a ogni step temporale (equispaziato) frate è il segnale da analizzare
   void save(void);

   char *name;
   int bridge;				// o per valanghe, 1 per bridge
   int umin;				// durata minima valanghe/bridge
   int umax;				// durata massima
   int n;				// numero intervalli temporali
   int *u1;				// estremo inferiore (chiuso) intervallo n-mo
   int *u2;				// estremo superiore (aperto)
   double smin;				// size minima istogrammi size
   double smax;				// size massima
   double ppdec;			// punti per decade
   int kmax;				// numero massimo punti per shape della valanga
   int flag;
   int flag2;
   int out;

   long t;
   long *tlast;
   double count;
   double Z;

   int M;		// numero segnali da analizzare
   int type;		// type=0 size discreta, type=1 size continua
   int hmax;		// numero intervalli della size
   double *s1;		// estremo inferiore (chiuso)
   double *s2;		// estremo superiore (chiuso)
   double *norm2;	// size media dell'intervallo

   double **V;
   double **norm;
   double *sum;
   double *H0;
   double *H1;
   double *H2;
   double *H3;
   double *S;
   double **H5;
   double **F;		// contiene il segnale da analizzare
   char *tmpdir;

   void avalanche(int m,long t1,int i,double weight);
  };

#ifndef __HEADERS__
#include <stdio.h>
#include <math.h>
#include <string.h>
#define __HEADERS__
#include "getmem.c"
#include "fopenf.c"
#include "random.c"
#include "getarg.c"
#include "debug.c"

shape::shape(int _M,char *_name)
  {
   M=_M;
   int l=strlen(_name);
   name=(char*)getmem(NULL,(l+1)*sizeof(char));
   strcpy(name,_name);
   flag=0;					// calcola shape delle valanghe/bridge
   flag2=0;					// calcola probabilità condizionata P(S|T) e congiunta P(S,T)
   out=0;					// quali file di output produrre
   bridge=(name[0]=='B'?1:0);
   if (bridge) flag=1;				// se bridge!=0 è necessario salvare le serie F[][], quindi flag deve essere diverso da zero

   umin=getarg_i("umin",1,"lower bound histogram of avalanche durations");                 // durata minima
   umax=getarg_i("umax",1000000,"higher bound \"    \"");                    // durata massima
   smin=getarg_d("smin",1,"lower bond histogram of avalanche sizes");
   smax=getarg_d("smax",1000000000,"higher bound \"   \"");                                           // size massima valanghe
   type=0;		// type=0: size discreta, type=1: size continua

   ppdec=20;
   // intervalli temporali
   u1=NULL;				// durata minima dell'intervallino
   u2=NULL;			// durata massima
   n=0;				// numero durate
   int utmp=umin;
   while (utmp<umax)
     {
      u1=(int*)getmem(u1,(n+1)*sizeof(int));
      u2=(int*)getmem(u2,(n+1)*sizeof(int));
      u1[n]=utmp;
      utmp=(int)rint(utmp*pow(10.,1./ppdec));
      if (utmp<=u1[n]) utmp=u1[n]+1;
      if (utmp>umax) utmp=umax;
      u2[n]=utmp;				// intero intervallo
      //u2[n]=u1[n]+1;				// singolo tempo
      n++;
     }
   umax=u2[n-1];
   // intervalli delle size
   hmax=1+(int)rint(ppdec*log(smax/smin)/M_LN10);
   s1=dvector(0,hmax-1);
   s2=dvector(0,hmax-1);
   norm2=dvector(0,hmax-1);
   for (int h=1;h<hmax;h++)
     {
      s1[h]=smin*exp((h-1)*log(smax/smin)/(hmax-1));
      s2[h]=smin*exp(h*log(smax/smin)/(hmax-1));
      if (type==0)
        {
         // variabile discreta: trova intero iniziale e finale dell'intervallo
         double eps=1e-12*s2[h];
         s1[h]=ceil(s1[h]-eps);
         s2[h]=floor(s2[h]-eps);
         if (s2[h]>=s1[h]) norm2[h]=1+s2[h]-s1[h];		// se s2[h]<s1[h] nessun intero capita nell'intervallo...
        }
      else norm2[h]=s2[h]-s1[h];
      //printf("intervallo %i: da %g a %g... %g valori\n",h,s1[h],s2[h],norm2[h]);
     }
   H0=dvector(0,n-1);					// conta i brige o le valanghe di durata da u1[i] a u2[i]-1
   H1=dvector(0,n-1);					// per le valanghe coincide con H0... per i bridge tiene conto di un fattore di normalizzazione (vedi dopo)
   H3=dvector(0,n-1);					// per calcolare size media delle valanghe di una certa durata...
   H2=dvector(0,hmax-1);					// conta valanghe con size nell'intervallo h
   S=dvector(0,M-1);
   tlast=(long*)getmem(NULL,M*sizeof(long));
   if (flag)
     {
      kmax=100;							// per calcolare la shape, dividi durata in (al massimo) kmax intervallini
      V=dmatrix(0,n-1,0,kmax-1);
      norm=dmatrix(0,n-1,0,kmax-1);
      sum=dvector(0,n-1);
      F=dmatrix(0,M-1,0,umax-1);                                   // serie del segnale negli ultimi umax tempi...
     }
   if (flag2)
     {
      H5=dmatrix(0,n-1,0,hmax);					// distribuzione delle size per una durata fissata...
     }
   // inizializza
   for (int m=0;m<M;m++)
     {
      S[m]=0;
      tlast[m]=-1;
     }
   t=0;
   count=0;
   Z=0;
   tmpdir=getarg_s("tmpdir",".","output directory");
  }

// registra una nuova valanga o bridge
// la valanga va dal bin t1 (vuoto per cui F[t1%umax]==0) al bin presente t (vuoto, anche se F[t%umax] non è stato ancora messo a zero)
// la durata della valanga è compresa nell'intervallo i-mo delle durate, che va da u1[i] a u2[i]-1
void shape::avalanche(int m,long t1,int i,double weight)
  {
   H0[i]++;
   H1[i]+=weight;
   double stmp=0;
   if (flag)
     {
      int ktmp=(u1[i]<kmax?u1[i]:kmax);
      //debug(0,"\nt=%li, valanga di durata %li (i=%i, ktmp=%i)... intervallo di durate %i - %i... numero punti shape: %i\n",t,t-t1-1,i,ktmp,u1[i],u2[i]-1,ktmp);
      double eps=1e-12;
      for (long u=t1+1;u<t;u++)
        {
         double ftmp=F[m][u%umax];
         double xtmp=(ktmp==1?0:(ktmp-1)*(u-t1-1)/(double)(t-t1-2));
         int k1=(int)floor(xtmp+eps);
         int k2=(int)ceil(xtmp-eps);
         // N.B: pesiamo sia le valanghe che i bridge con pesi 1 invece che weight
         // ma weight dipende solo da i, quindi se usassimo weight avremmo lo stesso fattore sia a numeratore (V[i][k]) che a denominatore (norm[i][k] oppure H0[i])
         // per cui non farebbe differenza
         double x1=(k2==k1?0.5:k2-xtmp);
         double x2=(k2==k1?0.5:xtmp-k1);
         //debug(0,"\tu=%i xtmp=%g k1=%i k2=%i x1=%g x2=%g ktmp*(u-t1-1)/(t-t1-1)=%i*%i/%i\n",u-t1,xtmp,k1,k2,x1,x2,ktmp,u-t1-1,t-t1-1);
         if (k1>=0 && k1<ktmp)
           {
            V[i][k1]+=x1*ftmp;
            norm[i][k1]+=x1;
           }
         if (k2>=0 && k2<ktmp)
           {
            V[i][k2]+=x2*ftmp;
            norm[i][k2]+=x2;
           }
         stmp+=ftmp;
        }
      //if (u1[i]>=20) exit(1);
     }
   else stmp=S[m];
   double eps=1e-12*stmp;
   int h=1+(int)floor((hmax-1)*log((stmp+eps)/smin)/log(smax/smin));		// trova bin corrispondente alla size stmp
   //printf("size=%g h=%i (durata %li)\n",stmp,h,t-t1-1);
   if (h>0 && h<hmax)
     {
      H2[h]+=weight;	// normalizza con Z		 (qui stiamo sommando nello stesso istogramma durate diverse, quindi è diverso sommare weight oppure 1)
      if (flag2) H5[i][h]+=weight; // normalizza con H1[i] (qui la durata è fissata, poiché weight dipende solo dalla durata, potremmo anche sommare 1 e normalizzare con H0[i])
     }
   H3[i]+=stmp;
   Z+=weight;		// numero totale di valanghe o bridge trovati (media virtuale nel caso dei bridge)
   count++;
  }

void shape::push(double *frate)
  {
   for (int m=0;m<M;m++)
     {
      if (frate[m]==0 && tlast[m]>=0)			// consideriamo solo valanghe che iniziano a tempi>0
        {
         // fine di una valanga (o bridge)
         if (bridge==0)
           {
            long tdel=t-tlast[m]-1;			// durata della valanga
            // troviamo l'intervallo i-mo per cui la durata della valanga è compresa nell'intervallo, ovvero (tdel>=u1[i] && tdel<u2[i])
            if (tdel>=umin && tdel<umax) for (int i=0;i<n;i++) if (tdel>=u1[i] && tdel<u2[i])
              {
               avalanche(m,tlast[m],i,1.);			// N.B: valanghe hanno peso 1
               break;					// tdel appartiene a un solo intervallo
              }
           }
         else
           {
            // BRIDGE: per ogni intervallo i delle durate, che va da t-u2[i]+1 a t-u1[i], quindi di lunghezza length=u2[i]-u1[i]
            // estraiamo un tempo a caso nell'intervallo e diamo un peso pari a length
            // infatti il numero di bridge che avremmo trovato se avessimo considerato tutti i tempi dell'intervallo
            // è dato in media da lenght per la frazione di volte che troviamo un bridge
            // il numero totale di bridge trovati è virtualmente dato da Z, ovvero Z rappresenta in media il numero di bridge che avremmo
            // trovato se avessimo provato tutti i tempi dei vari intervalli...
            // nel caso delle valanghe Z è invece esattamente uguale al numero di valanghe trovate (Z==count)
            // dunque P(S) sarà dato dal numero di valanghe/bridge di dimensione S diviso per il numero di valanghe/bridge totali
            // da dividere per l'ampiezza del bin per ottenere una densità P(S)... analogamente per P(T)
            for (int i=0;i<n;i++)
              {
               double length=u2[i]-u1[i];
               double weight=length;
               long t1=t-u2[i]+(int)ceil(length*Xrandom());		// N.B: t1 va da t-u2[i]+1 a t-u1[i]... se u2[i]==u1[i]+1 allora t1=t-u1[i]
               if (F[m][t1%umax]!=0) continue;
               avalanche(m,t1,i,weight);
              }
           }
        }
      if (flag) F[m][t%umax]=frate[m];
      if (frate[m]==0)
        {
         S[m]=0;
         tlast[m]=t;
        }
      else S[m]+=frate[m];
     }
   t++;
  }

void shape::save(void)
  {
   debug(0,"%s: steps %li number of avalanches: %g\n",name,t,count);
   FILE *stream=fopenf("%s/histo-%s.dat","w",tmpdir,name);
   double x0=0;
   double y1=0;
   for (int h=1;h<hmax;h++) if (norm2[h]>0)
     {
      double us=sqrt(s1[h]*s2[h]);
      double PS=H2[h]/(Z*norm2[h]);
      double d1=log(PS/y1)/log(us/x0);
      fprintf(stream,"%12g %12g %12g\n",us,PS,d1);
      x0=us;
      y1=PS;
     }
   fclose(stream);
   FILE *stream1=fopenf("%s/histo1-%s.dat","w",tmpdir,name);
   double x1=0;
   double y2=0;
   double y3=0;
   for (int i=0;i<n;i++)
     {
      double um=sqrt(u1[i]*(u2[i]-1.));                         // durata media dell'intervallo
      double PT=H1[i]/(Z*(u2[i]-u1[i]));
      double ST=H3[i]/H0[i];
      double m3=0;			// skewness
      int ktmp=0;
      double vsum=0;
      if (flag)
        {
         sum[i]=0;
         ktmp=(u1[i]<kmax?u1[i]:kmax);		// su quanti punti è calcolata la shape...
         // calcola momenti della shape (come distribuzione)
         double sum0=0;
         double sum1=0;
         double sum2=0;
         double sum3=0;
         for (int k=0;k<ktmp;k++) if (norm[i][k]>0)
           {
            double xtmp=(1+k)/(1.+ktmp);
            double ytmp=V[i][k]/norm[i][k];
            sum0+=ytmp;
            sum1+=xtmp*ytmp;
            sum2+=xtmp*xtmp*ytmp;
            sum3+=xtmp*xtmp*xtmp*ytmp;
            sum[i]+=V[i][k];
           }
         double m1=sum1/sum0;                                                              // valore medio della shape... un valore negativo indica skewness a sinistra
         double m2=(sum2/sum0-m1*m1);
         m3=(sum3/sum0-3*m1*m2-m1*m1*m1)/pow(m2,1.5);                               // skewness
         vsum=sum[i]/H0[i];
        }
      double d2=log(PT/y2)/log(um/x1);
      double d3=log(ST/y3)/log(um/x1);
      //fprintf(stream1,"%12g %12g %12g %12g %12g %12g %12g %12i %12g\n",um,PT,d2,ST,d3,m3,vsum,i,H0[i]);
      //fprintf(stream1,"%12g %12g %12g %12g %12g %12g %12i %12g\n",um,PT,d2,ST,d3,m3,i,H0[i]);
      fprintf(stream1,"%12g %12g %12g %12g %12g\n",um,PT,d2,ST,d3);
      x1=um;
      y2=PT;
      y3=ST;
     }
   fclose(stream1);
   // scrivi file delle shape
   if (flag && out&4)
     {
      for (int i=0;i<n;i++) if (H0[i]>0)
        {
         int ktmp=(u1[i]<kmax?u1[i]:kmax);
         FILE *stream3=fopenf("%s/shape-%s-%i.dat","w",tmpdir,name,i);
         fprintf(stream3,"0 0 0 0 0\n");
         for (int k=0;k<ktmp;k++)
           {
            double xtmp=(1+k)/(1.+ktmp);
            fprintf(stream3,"%12g %12g %12g %12g\n",xtmp,norm[i][k]/H0[i],V[i][k]/H0[i],V[i][k]/norm[i][k]);
           }
         fprintf(stream3,"1 0 0 0 0\n");
         fclose(stream3);
        }
     }
   // scrivi file histo2 con la distribuzione delle size
   if (flag2 && out&2)
     {
      double *Ha=dvector(0,hmax-1);
      for (int i=0;i<n;i++) if (H0[i]>0)
        {
         double PT=H1[i]/(Z*(u2[i]-u1[i]));
         FILE *stream2=fopenf("%s/histo2-%s-%i.dat","w",tmpdir,name,i);
         for (int h=1;h<hmax;h++) if (norm2[h]>0)
           {
            double PST=H5[i][h]/(H1[i]*norm2[h]);                       // probabilità condizionata di avere una size nell'intervallo h-mo dato che la durata è nell'intervallo i-mo
            double PSvT=PT*PST*(u2[i]-u1[i]);                           // probabilità congiunta di T (nell'intervallo i-mo) e S
            fprintf(stream2,"%12g %12g %12g\n",sqrt(s1[h]*s2[h]),PST,PSvT);
            Ha[h]+=PSvT;
            // la probabilità PSvT è data da H5[i][h]/(Z*norm2[h])
            // dunque la somma su i (ovvero Ha[h]) deve essere uguale a H2[h]/(Z*norm2[h]))
           }
         fclose(stream2);
        }
      // check di consistenza
      double xmax=0;
      for (int h=0;h<hmax;h++)
        {
         double atmp=H2[h]/(Z*norm2[h]);
         double xtmp=fabs((Ha[h]-atmp)/atmp);
         if (xtmp>xmax) xmax=xtmp;
        }
      free(Ha);
      //printf("check di consistenza: xmax=%g\n",xmax);
     }
  }
#endif
#endif
